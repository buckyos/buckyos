archive fact: AICC-ZIP-8642
